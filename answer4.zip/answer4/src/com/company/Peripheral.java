package com.company;

public class Peripheral {
    private double price=45;
    private int sales=0;

    Peripheral(){
    }

    public double calculate(){
        return price*sales;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSales() {
        return sales;
    }

    public void setSales(int sales) {
        this.sales = sales;
    }
}
