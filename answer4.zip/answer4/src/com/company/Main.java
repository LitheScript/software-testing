package com.company;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.Scanner;

public class Main {

    public static int MAXHOST=70;
    public static int MAXDISPLAYS=80;
    public static int MAXPERIPHERAL=90;


    public static void main(String[] args) {

        double totalSales=0;
        double commission=0;
        int salesOfHost=0,salesOfDisplays=0,salesOfPeripheral=0;
        Host host = new Host();
        Displays displays = new Displays();
        Peripheral peripheral = new Peripheral();
        while(true) {
            Scanner in =new Scanner(System.in);
            System.out.println("请输入销售量");
            if (in.hasNext()) {
                salesOfHost = in.nextInt();
                if (salesOfHost < 1&&salesOfHost!=-1) {
                    System.out.println("error!请输入大于1的数");
                }else if (salesOfHost > MAXHOST) {
                    System.out.println("error!超过主机最大销售量");
                }
                if (salesOfHost == -1) {
                    totalSales = host.calculate() + displays.calculate() + peripheral.calculate();
                    System.out.println("销售总额为" + totalSales);

                    if (totalSales <= 1000) {
                        commission = totalSales * 0.1;
                    } else if (totalSales > 1000 && totalSales <= 1800) {
                        commission = totalSales * 0.15;
                    } else if (totalSales > 1800) {
                        commission = totalSales * 0.2;
                    }
                    System.out.println("佣金为" + commission);
                    continue;
                }
               host.setSales(salesOfHost);

            } else {
                System.out.println("error！请输入整数");
            }
            if (in.hasNextInt()) {
                salesOfDisplays = in.nextInt();
                if (salesOfDisplays < 1) {
                    System.out.println("error!请输入大于1的数");
                } else if (salesOfDisplays > MAXDISPLAYS) {
                    System.out.println("error!超过显示屏最大销售量");
                }
                displays.setSales(salesOfDisplays);
            } else {
                System.out.println("error!请输入整数");
            }
            if (in.hasNextInt()) {
                salesOfPeripheral = in.nextInt();
                if (salesOfPeripheral < 1) {
                    System.out.println("error!请输入大于1的数");
                } else if (salesOfPeripheral > MAXPERIPHERAL) {
                    System.out.println("error!超过外设最大销售量");
                }
                peripheral.setSales(salesOfPeripheral);
            } else {
                System.out.println("error!请输入整数");
            }
        }
    }
}
