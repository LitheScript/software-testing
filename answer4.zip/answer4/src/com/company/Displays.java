package com.company;

public class Displays {
    private double price=30;
    private int sales=0;

    Displays(){
    }

    public double calculate(){
        return price*sales;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSales() {
        return sales;
    }

    public void setSales(int sales) {
        this.sales = sales;
    }
}
