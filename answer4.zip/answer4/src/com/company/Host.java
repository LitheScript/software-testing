package com.company;

public class Host {
    private double price=25;
    private int sales=0;

    Host(){
    }

    public double calculate(){
        return price*sales;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getSales() {
        return sales;
    }

    public void setSales(int sales) {
        this.sales = sales;
    }
}
